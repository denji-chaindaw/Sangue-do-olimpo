extends Control

# Limiar do Olimpo - v2
# Sprites pixel art em res://assets/olimpo/, colisão, combate, missões, save e controles touch.
# Resolução de design fixa em 1280x720 (o Godot escala para qualquer tela, inclusive Android).

const VIEW := Vector2(1280, 720)
const TEX_DIR := "res://assets/olimpo/"
const SAVE_PATH := "user://limiar_save.json"

const CABINS := [
    ["Zeus", "Céu, trovão e liderança", Color("7a63d8")], ["Hera", "Família e união", Color("b67f62")],
    ["Poseidon", "Mar, cavalos e terremotos", Color("3d8edb")], ["Deméter", "Colheita e natureza", Color("6eaa50")],
    ["Ares", "Coragem e batalha", Color("c84d48")], ["Atena", "Sabedoria e estratégia", Color("9b7841")],
    ["Apolo", "Sol, música e cura", Color("d99a32")], ["Ártemis", "Lua e caça", Color("7996b4")],
    ["Hefesto", "Forja e invenção", Color("c95a3b")], ["Afrodite", "Amor e beleza", Color("d97e9d")],
    ["Hermes", "Viagens e mensagens", Color("c6a64b")], ["Dionísio", "Festa e vinhas", Color("d65f9f")],
    ["Hades", "Mundos profundos", Color("543f78")], ["Íris", "Arco-íris e pontes", Color("ae74c7")],
    ["Hipnos", "Sono e sonhos", Color("7566b2")], ["Nêmesis", "Equilíbrio e retribuição", Color("71808e")],
    ["Nike", "Vitória e velocidade", Color("c84d48")], ["Hebe", "Juventude e vitalidade", Color("6cc2a0")],
    ["Tique", "Sorte e caminhos", Color("d2b85a")], ["Hécate", "Magia e encruzilhadas", Color("80b4b8")]
]
const RESIDENTS := ["Selene", "Tomás", "Cássia", "Bruno", "Helena", "Davi", "Irene", "Caio", "Marina", "Rafael",
    "Júlia", "Otto", "Nara", "Felipe", "Luna", "Gael", "Vera", "Théo", "Alice", "Ícaro"]
const NPC_LINES := {
    "Lia": ["Oi! Eu sou a Lia. O acampamento é maior do que parece.", "As sombras vêm do norte, cuidado com elas.", "Você está se saindo bem. Quer treinar comigo um dia?", "Confio em você para as próximas missões.", "Somos uma boa equipe, sabia?", "Fico feliz que você tenha chegado ao acampamento."],
    "Nico": ["Fala, novato! Eu cuido das armas.", "Dica: o poder do seu chalé acerta vários inimigos de uma vez.", "Poções de energia salvam vidas. Compre algumas.", "Já vi muita gente fugir das sombras. Você não.", "Se precisar de um parceiro de treino, estou aqui.", "Você já é uma lenda no meu livro."],
    "Quíron": ["Bem-vindo ao Acampamento. Aqui treinamos semideuses.", "Cada chalé guarda histórias. Visite todos.", "A coragem não é ausência de medo, jovem.", "Você honra seu parente divino.", "Poucos chegam tão longe tão rápido.", "O Olimpo observa você."]
}

var screen := "title"
var panel_kind := ""
var player_name := "Ari"
var model := 0
var divine_parent := 0
var difficulty := 1
var level := 1
var xp := 0
var skill_points := 0
var coins := 120
var hearts := 5
var max_hearts := 5
var energy := 100.0
var kills := 0
var potions := 1
var owned := {"shirt": false, "cloak": false}
var skills := {"speed": false, "guard": false, "ancestral": false}
var quests := {"shadows": 0}
var quest_done := {"shadows": false, "cabin": false, "friends": false}
var friendship := {"Lia": 1, "Nico": 0, "Quíron": 0}
var met := {}
var talked_today := {}
var opened_chests := {}
var visited_cabins := {}
var cabin_talked := {}
var game_minutes := 980.0
var day := 1
var sound_on := true
var touch_mode := 0

var player_pos := Vector2(640, 470)
var facing := Vector2.DOWN
var walk_t := 0.0
var moving := false
var monsters: Array = []
var spawn_timer := 4.0
var attack_cd := 0.0
var power_cd := 0.0
var shield_cd := 0.0
var shield_t := 0.0
var hurt_cd := 0.0
var slash_t := 0.0
var fx: Array = []
var active_cabin := -1
var dialogue := "Bem-vindo ao acampamento. Explore a praça e conheça seus vizinhos."
var dialogue_time := 8.0
var toast := ""
var toast_time := 0.0
var controls: Array[Control] = []
var joy_touch := -1
var joystick_vector := Vector2.ZERO
var tex := {}
var statics: Array = []
var blockers: Array = []
var cabin_sprite_names: Array = []
var npcs: Array = []
var target: Dictionary = {}

func _ready() -> void:
    var win := get_window()
    win.content_scale_size = Vector2i(1280, 720)
    win.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
    win.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_KEEP
    RenderingServer.set_default_clear_color(Color("0f1b29"))
    get_tree().set_auto_accept_quit(false)
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    _ensure_actions()
    _pick_cabin_sprites()
    _build_world()
    set_process(true)
    _build_title()

func _ensure_actions() -> void:
    var map := {
        "move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT], "move_up": [KEY_W, KEY_UP], "move_down": [KEY_S, KEY_DOWN],
        "interact": [KEY_E], "attack": [KEY_SPACE, KEY_J], "power1": [KEY_K, KEY_Q], "power2": [KEY_L, KEY_F],
        "slot1": [KEY_1], "menu": [KEY_ESCAPE]
    }
    for action in map:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
            for k in map[action]:
                var ev := InputEventKey.new()
                ev.keycode = k
                InputMap.action_add_event(action, ev)

func _t(n: String) -> Texture2D:
    if tex.has(n):
        return tex[n]
    var path := TEX_DIR + n + ".png"
    var t: Texture2D = null
    if ResourceLoader.exists(path):
        t = load(path)
    else:
        var img := Image.load_from_file(path)
        if img != null:
            t = ImageTexture.create_from_image(img)
    tex[n] = t
    return t

func _pick_cabin_sprites() -> void:
    var refs := {"sol": Color("c84d48"), "lua": Color("3d8edb"), "folha": Color("6eaa50"), "estrela": Color("7a63d8")}
    cabin_sprite_names.clear()
    for i in range(CABINS.size()):
        var c: Color = CABINS[i][2]
        var best := "sol"
        var best_d := 99.0
        for k in refs:
            var r: Color = refs[k]
            var d := absf(c.r - r.r) + absf(c.g - r.g) + absf(c.b - r.b)
            if d < best_d:
                best_d = d
                best = k
        cabin_sprite_names.append(best)

# ---------------------------------------------------------------- mundo
func _cabin_pos(i: int) -> Vector2:
    if i < 6:
        return Vector2(18 + i * 84, 84)
    if i < 12:
        return Vector2(768 + (i - 6) * 84, 84)
    if i < 16:
        return Vector2(1190, 212 + (i - 12) * 84)
    return Vector2(14, 212 + (i - 16) * 84)

func _cabin_door(i: int) -> Vector2:
    var p := _cabin_pos(i)
    if i < 12:
        return p + Vector2(37, 92)
    if i < 16:
        return p + Vector2(-14, 62)
    return p + Vector2(88, 62)

func _add_static(n: String, base: Vector2, block := Rect2(), tint := Color.WHITE) -> void:
    var t := _t(n)
    if t == null:
        return
    var s := t.get_size()
    statics.append({"y": base.y, "t": t, "p": base - Vector2(s.x * 0.5, s.y), "m": tint, "s": s})
    if block.size.x > 0.0:
        blockers.append(block)

func _build_world() -> void:
    statics.clear()
    blockers.clear()
    for i in range(20):
        var p := _cabin_pos(i)
        var n: String = "cabin_" + str(cabin_sprite_names[i])
        var t := _t(n)
        if t != null:
            var s := t.get_size()
            statics.append({"y": p.y + s.y, "t": t, "p": p, "m": Color.WHITE, "s": s, "num": i + 1, "col": CABINS[i][2]})
            blockers.append(Rect2(p.x + 6, p.y + 34, s.x - 12, s.y - 38))
    var cas := _t("casarao")
    if cas != null:
        var cs := cas.get_size()
        statics.append({"y": 70.0 + cs.y, "t": cas, "p": Vector2(524, 70), "m": Color.WHITE, "s": cs, "label": "CASARÃO"})
        blockers.append(Rect2(530, 100, cs.x - 12, cs.y - 104))
    var fog := _t("fogueira")
    if fog != null:
        var fs := fog.get_size()
        statics.append({"y": 330.0, "t": fog, "p": Vector2(640 - fs.x * 0.5, 430 - fs.y * 0.5), "m": Color.WHITE, "s": fs})
        blockers.append(Rect2(618, 414, 44, 30))
    var trees := [[40, 600, "tree_a"], [95, 585, "tree_c"], [160, 612, "tree_b"], [235, 598, "tree_d"], [300, 614, "tree_e"], [20, 545, "tree_h"], [70, 528, "tree_f"],
        [1240, 602, "tree_b"], [1182, 590, "tree_a"], [1110, 614, "tree_c"], [1040, 600, "tree_h"], [980, 612, "tree_e"], [1255, 552, "tree_d"], [1210, 566, "tree_g"],
        [440, 614, "tree_g"], [520, 608, "tree_f"], [760, 612, "tree_f"], [840, 606, "tree_g"],
        [260, 300, "tree_e"], [420, 340, "tree_d"], [900, 310, "tree_c"], [1020, 345, "tree_e"], [220, 485, "tree_g"], [1000, 475, "tree_f"]]
    for t in trees:
        _add_static(str(t[2]), Vector2(t[0], t[1]), Rect2(t[0] - 9, t[1] - 8, 18, 8))
    var bushes := [[350, 252, "bush_b"], [566, 262, "bush_a"], [718, 262, "bush_c"], [880, 252, "bush_d"], [150, 335, "bush_e"], [1120, 385, "bush_a"],
        [330, 488, "bush_b"], [930, 508, "bush_c"], [560, 566, "bush_d"], [740, 552, "bush_e"]]
    for b in bushes:
        _add_static(str(b[2]), Vector2(b[0], b[1]))
    var rocks := [[200, 365, "rock_a"], [1060, 545, "rock_b"], [460, 524, "rock_c"], [820, 336, "rock_c"]]
    for r in rocks:
        var rt := _t(str(r[2]))
        var rw := 30.0
        if rt != null:
            rw = rt.get_size().x * 0.7
        _add_static(str(r[2]), Vector2(r[0], r[1]), Rect2(r[0] - rw * 0.5, r[1] - 12, rw, 12))
    _add_static("lantern", Vector2(548, 392), Rect2(543, 386, 10, 6))
    _add_static("lantern", Vector2(732, 392), Rect2(727, 386, 10, 6))
    _add_static("bench", Vector2(520, 470), Rect2(494, 458, 52, 12))
    _add_static("bench", Vector2(760, 470), Rect2(734, 458, 52, 12))
    _add_static("sign", Vector2(590, 236), Rect2(582, 228, 16, 8))
    _add_static("crate_a", Vector2(500, 252), Rect2(486, 238, 28, 14))
    _add_static("crate_b", Vector2(528, 256), Rect2(514, 242, 28, 14))
    _add_static("barrel", Vector2(790, 254), Rect2(780, 244, 20, 10))
    _add_static("stump", Vector2(330, 424), Rect2(314, 414, 32, 10))
    _add_static("log", Vector2(880, 448), Rect2(852, 438, 56, 10))
    _add_static("fence", Vector2(1100, 460), Rect2(1066, 450, 68, 10))
    blockers.append(Rect2(0, 622, 1280, 100))
    npcs = [
        {"name": "Lia", "pos": Vector2(710, 474), "tex": "garota", "tint": Color.WHITE},
        {"name": "Nico", "pos": Vector2(572, 476), "tex": "garoto", "tint": Color(0.78, 0.9, 1.15)},
        {"name": "Quíron", "pos": Vector2(704, 240), "tex": "centauro", "tint": Color.WHITE}
    ]

func _blocked(p: Vector2) -> bool:
    if p.x < 16.0 or p.x > 1264.0 or p.y < 98.0 or p.y > 620.0:
        return true
    var r := Rect2(p.x - 9, p.y - 7, 18, 7)
    for b in blockers:
        if r.intersects(b):
            return true
    for n in npcs:
        var np: Vector2 = n["pos"]
        if Rect2(np.x - 12, np.y - 7, 24, 7).intersects(r):
            return true
    return false

# ---------------------------------------------------------------- entrada
func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.is_action_pressed("menu"):
            _on_back()
            get_viewport().set_input_as_handled()
            return
        if screen == "camp":
            if event.is_action_pressed("interact"):
                _interact()
            elif event.is_action_pressed("attack"):
                _attack()
            elif event.is_action_pressed("power1"):
                _power_slot(1)
            elif event.is_action_pressed("power2"):
                _power_slot(2)
            elif event.is_action_pressed("slot1"):
                _use_potion()

func _input(event: InputEvent) -> void:
    if screen != "camp" or not _touch_visible():
        return
    var base := Vector2(150, 596)
    if event is InputEventScreenTouch:
        if event.pressed:
            if joy_touch == -1 and event.position.distance_to(base) < 120.0:
                joy_touch = event.index
                joystick_vector = ((event.position - base).limit_length(70.0)) / 70.0
        elif event.index == joy_touch:
            joy_touch = -1
            joystick_vector = Vector2.ZERO
    elif event is InputEventScreenDrag and event.index == joy_touch:
        joystick_vector = ((event.position - base).limit_length(70.0)) / 70.0

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        _on_back()
    elif what == NOTIFICATION_WM_CLOSE_REQUEST:
        if screen != "title" and screen != "creation":
            _save_game()
        get_tree().quit()
    elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        if screen == "camp":
            _save_game()

func _on_back() -> void:
    match screen:
        "camp":
            _show_pause()
        "panel", "cabins", "cabin":
            _enter_camp()
        "creation", "help":
            _build_title()
        "title":
            pass

func _touch_visible() -> bool:
    if touch_mode == 1:
        return true
    if touch_mode == 2:
        return false
    return DisplayServer.is_touchscreen_available() or OS.has_feature("android") or OS.has_feature("ios")

# ---------------------------------------------------------------- widgets
func _clear_controls() -> void:
    for c in controls:
        if is_instance_valid(c):
            c.queue_free()
    controls.clear()
    joy_touch = -1
    joystick_vector = Vector2.ZERO

func _button(text: String, pos: Vector2, button_size: Vector2, callback: Callable, accent := Color("d6a64b"), font_size := 18) -> Button:
    var b := Button.new()
    b.text = text
    b.position = pos
    b.size = button_size
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", font_size)
    b.add_theme_color_override("font_color", Color("fff4d0"))
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_color_override("font_disabled_color", Color("7f8c94"))
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color("26374a")
    normal.border_color = accent
    normal.set_border_width_all(2)
    normal.set_corner_radius_all(6)
    var hover := normal.duplicate()
    hover.bg_color = Color("3d5870")
    var off := normal.duplicate()
    off.bg_color = Color("1c2a38")
    off.border_color = Color("4a5a66")
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("pressed", hover)
    b.add_theme_stylebox_override("disabled", off)
    b.pressed.connect(callback)
    add_child(b)
    controls.append(b)
    return b

func _label(text: String, pos: Vector2, font_size := 18, color := Color("fff4d0")) -> Label:
    var l := Label.new()
    l.text = text
    l.position = pos
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    add_child(l)
    controls.append(l)
    return l

func _centered(text: String, y: float, font_size: int, color: Color) -> void:
    var l := _label(text, Vector2(0, y), font_size, color)
    l.size = Vector2(VIEW.x, font_size + 16)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _say(text: String, seconds := 7.0) -> void:
    dialogue = text
    dialogue_time = seconds

func _toast(text: String, seconds := 2.4) -> void:
    toast = text
    toast_time = seconds

# ---------------------------------------------------------------- telas
func _build_title() -> void:
    _clear_controls()
    screen = "title"
    _centered("LIMIAR DO OLIMPO", 62, 46, Color("ffe7a0"))
    _centered("Ecos do Acampamento", 126, 24, Color("9bd5d0"))
    _centered("RPG de exploração - pixel art - versão de demonstração", 170, 15, Color("b7c9bf"))
    _button("Criar semideus", Vector2(VIEW.x / 2.0 - 150, 285), Vector2(300, 52), _show_creation, Color("d6a64b"))
    _button("Continuar aventura", Vector2(VIEW.x / 2.0 - 150, 350), Vector2(300, 52), _continue_game, Color("659c83"))
    _button("Como jogar", Vector2(VIEW.x / 2.0 - 150, 415), Vector2(300, 52), _show_help, Color("6d8fb3"))
    _centered("Desktop: WASD ou setas - Android: joystick e botões na tela", 668, 14, Color("9aaeb4"))

func _continue_game() -> void:
    if _load_game():
        _enter_camp()
    else:
        _toast("Nenhum jogo salvo ainda. Crie um semideus.")

func _show_creation() -> void:
    _clear_controls()
    screen = "creation"
    _label("CRIAR SEMIDEUS", Vector2(55, 38), 34, Color("ffe7a0"))
    _label("A prévia é atualizada ao vivo", Vector2(58, 80), 16, Color("9bd5d0"))
    _label("Nome", Vector2(58, 135), 17)
    var name_edit := LineEdit.new()
    name_edit.text = player_name
    name_edit.max_length = 14
    name_edit.position = Vector2(58, 164)
    name_edit.size = Vector2(300, 42)
    name_edit.add_theme_font_size_override("font_size", 18)
    name_edit.text_changed.connect(func(v: String): player_name = v if v.strip_edges() != "" else "Ari")
    add_child(name_edit)
    controls.append(name_edit)
    _label("Aparência", Vector2(58, 235), 19, Color("ffe7a0"))
    _button("Personagem  <  " + ["Garoto", "Garota"][model] + "  >", Vector2(58, 272), Vector2(300, 46), func(): model = (model + 1) % 2; _show_creation(), Color("6d8fb3"))
    _button("Dificuldade  <  " + ["Fácil", "Normal", "Difícil"][difficulty] + "  >", Vector2(58, 330), Vector2(300, 46), func(): difficulty = (difficulty + 1) % 3; _show_creation(), Color("d6a64b"))
    _label("Romances são opcionais, progressivos e não explícitos.", Vector2(58, 548), 14, Color("d8b8c1"))
    _label("Parente divino", Vector2(640, 105), 19, Color("ffe7a0"))
    _label("Ordem dos chalés e afinidade inicial", Vector2(642, 138), 14, Color("b7c9bf"))
    for i in range(6):
        var p := i
        _button(str(i + 1) + ". " + str(CABINS[i][0]), Vector2(640 + (i % 3) * 170, 175 + (i / 3) * 58), Vector2(155, 44), func(): _choose_parent(p), CABINS[i][2])
    _label("Afinidade: " + str(CABINS[divine_parent][0]) + " - " + str(CABINS[divine_parent][1]), Vector2(642, 300), 16, CABINS[divine_parent][2])
    _button("Voltar", Vector2(58, 610), Vector2(180, 46), _build_title, Color("71808e"))
    _button("Entrar no acampamento", Vector2(850, 610), Vector2(300, 46), _new_game, Color("659c83"))

func _choose_parent(index: int) -> void:
    divine_parent = index
    _show_creation()

func _show_help() -> void:
    _clear_controls()
    screen = "help"
    _label("COMO JOGAR", Vector2(70, 60), 34, Color("ffe7a0"))
    _label("Explore a praça, entre em cada chalé pela porta e converse com os campistas.", Vector2(100, 140), 19)
    var rows := [["WASD / setas", "Mover o personagem", Color("9bd5d0")], ["E", "Interagir: conversar, entrar em chalés", Color("9bd5d0")],
        ["Espaço / J", "Ataque corpo a corpo", Color("d97e9d")], ["K / Q", "Poder do seu chalé (gasta energia)", Color("d97e9d")],
        ["L / F", "Escudo divino (invulnerável por 4 s)", Color("d97e9d")], ["1", "Usar poção de energia", Color("d6a64b")],
        ["Esc", "Pausa / voltar", Color("d6a64b")], ["Android", "Joystick e botões na tela; voltar = pausa", Color("d6a64b")]]
    for i in range(rows.size()):
        _label(str(rows[i][0]), Vector2(120, 200 + i * 46), 20, rows[i][2])
        _label(str(rows[i][1]), Vector2(360, 202 + i * 46), 17)
    _button("Voltar", Vector2(100, 600), Vector2(220, 50), _build_title, Color("659c83"))

func _new_game() -> void:
    level = 1
    xp = 0
    skill_points = 0
    coins = 120
    max_hearts = 5
    hearts = 5
    energy = 100.0
    kills = 0
    potions = 1
    owned = {"shirt": false, "cloak": false}
    skills = {"speed": false, "guard": false, "ancestral": false}
    quests = {"shadows": 0}
    quest_done = {"shadows": false, "cabin": false, "friends": false}
    friendship = {"Lia": 1, "Nico": 0, "Quíron": 0}
    met = {}
    talked_today = {}
    opened_chests = {}
    visited_cabins = {}
    cabin_talked = {}
    game_minutes = 980.0
    day = 1
    player_pos = Vector2(640, 470)
    monsters.clear()
    spawn_timer = 3.0
    _say("Bem-vindo ao acampamento, " + player_name + "! Fale com Lia, Nico e Quíron. Esc abre a pausa.", 9.0)
    _enter_camp()
    _save_game()

func _enter_camp() -> void:
    _clear_controls()
    screen = "camp"
    panel_kind = ""
    active_cabin = -1
    _build_camp_controls()

func _build_camp_controls() -> void:
    var y := 12.0
    var x := 356.0
    var items := [["Mapa", 84, _show_cabins, Color("659c83")], ["Missões", 96, _show_quests, Color("d6a64b")], ["Habilidades", 118, _show_skills, Color("8e77bd")],
        ["Amizades", 100, _show_relationships, Color("d97e9d")], ["Loja", 72, _show_shop, Color("b67f62")], ["Mochila", 92, _show_inventory, Color("b67f62")], ["Pausa", 78, _show_pause, Color("71808e")]]
    for it in items:
        var w: float = float(it[1])
        _button(str(it[0]), Vector2(x, y), Vector2(w, 40), it[2], it[3], 16)
        x += w + 7.0
    if _touch_visible():
        _button("ATAQUE", Vector2(1150, 640), Vector2(104, 60), _attack, Color("c84d48"), 17)
        _button("PODER", Vector2(1034, 640), Vector2(104, 60), func(): _power_slot(1), CABINS[divine_parent][2], 17)
        _button("ESCUDO", Vector2(1150, 570), Vector2(104, 60), func(): _power_slot(2), Color("8e77bd"), 17)
        _button("AÇÃO", Vector2(1034, 570), Vector2(104, 60), _interact, Color("6d8fb3"), 17)

func _panel(title: String, kind: String) -> void:
    _clear_controls()
    screen = "panel"
    panel_kind = kind
    _label(title, Vector2(70, 46), 32, Color("ffe7a0"))

func _back_button(y := 620.0) -> void:
    _button("Voltar à praça", Vector2(100, y), Vector2(240, 50), _enter_camp, Color("659c83"))

func _show_pause() -> void:
    _panel("PAUSA", "pause")
    _button("Continuar", Vector2(520, 190), Vector2(240, 54), _enter_camp, Color("659c83"))
    _button("Salvar jogo", Vector2(520, 256), Vector2(240, 54), func(): _save_game(); _toast("Jogo salvo!"), Color("d6a64b"))
    _button("Configurações", Vector2(520, 322), Vector2(240, 54), _show_settings, Color("6d8fb3"))
    _button("Salvar e sair para o menu", Vector2(480, 388), Vector2(320, 54), func(): _save_game(); _build_title(), Color("c84d48"))

func _show_settings() -> void:
    _panel("CONFIGURAÇÕES", "settings")
    _label("Os ajustes são salvos automaticamente.", Vector2(75, 100), 17, Color("9bd5d0"))
    _button("Dificuldade: " + ["Fácil", "Normal", "Difícil"][difficulty], Vector2(110, 180), Vector2(320, 58), func(): difficulty = (difficulty + 1) % 3; _show_settings(), Color("d6a64b"))
    _button("Som: " + ("ligado" if sound_on else "desligado"), Vector2(460, 180), Vector2(320, 58), _toggle_sound, Color("659c83"))
    _button("Controles de toque: " + ["auto", "sempre", "nunca"][touch_mode], Vector2(810, 180), Vector2(360, 58), func(): touch_mode = (touch_mode + 1) % 3; _show_settings(), Color("6d8fb3"))
    _back_button()

func _toggle_sound() -> void:
    sound_on = not sound_on
    AudioServer.set_bus_mute(0, not sound_on)
    _show_settings()

func _show_cabins() -> void:
    _clear_controls()
    screen = "cabins"
    _label("OS 20 CHALÉS", Vector2(65, 40), 34, Color("ffe7a0"))
    _label("Toque em um chalé para entrar. Visitados: " + str(visited_cabins.size()) + "/20", Vector2(66, 82), 16, Color("9bd5d0"))
    for i in range(20):
        var idx := i
        var x := 70.0 + (i % 4) * 270.0
        var y := 130.0 + (i / 4) * 78.0
        var mark := "  OK" if visited_cabins.has(i) else ""
        _button(str(i + 1).pad_zeros(2) + "  " + str(CABINS[i][0]) + mark, Vector2(x, y), Vector2(240, 54), func(): _enter_cabin(idx), CABINS[i][2])
    _button("Voltar à praça", Vector2(70, 630), Vector2(220, 48), _enter_camp, Color("659c83"))

func _enter_cabin(index: int) -> void:
    active_cabin = index
    visited_cabins[index] = true
    _clear_controls()
    screen = "cabin"
    var god: String = str(CABINS[index][0])
    _label("CHALÉ " + str(index + 1).pad_zeros(2) + "  -  " + god.to_upper(), Vector2(65, 42), 30, CABINS[index][2])
    _label(str(CABINS[index][1]), Vector2(68, 90), 17, Color("b7c9bf"))
    _label("Morador: " + str(RESIDENTS[index]), Vector2(900, 55), 16, Color("9aaeb4"))
    var opened := "Baú (vazio)" if opened_chests.has(index) else "Investigar baú"
    _button(opened, Vector2(70, 600), Vector2(210, 50), _inspect_item, Color("b67f62"))
    _button("Conversar", Vector2(295, 600), Vector2(190, 50), _talk_to_resident, Color("d97e9d"))
    _button("Descansar", Vector2(500, 600), Vector2(190, 50), _rest, Color("8e77bd"))
    _button("Lista de chalés", Vector2(705, 600), Vector2(220, 50), _show_cabins, Color("659c83"))
    _button("Voltar à praça", Vector2(940, 600), Vector2(220, 50), _leave_cabin, Color("6d8fb3"))

func _leave_cabin() -> void:
    _enter_camp()

func _inspect_item() -> void:
    if opened_chests.has(active_cabin):
        _toast("O baú está vazio.")
        return
    opened_chests[active_cabin] = true
    var gain := 15 + active_cabin
    coins += gain
    _toast("Você encontrou %d dracmas no baú." % gain)
    if not quest_done["cabin"]:
        quest_done["cabin"] = true
        coins += 40
        _gain_xp(40)
        _toast("Missão bônus concluída: +40 dracmas e +40 XP!", 3.2)
    _enter_cabin(active_cabin)

func _talk_to_resident() -> void:
    var god: String = str(CABINS[active_cabin][0])
    var who: String = str(RESIDENTS[active_cabin])
    _say("%s: Aqui no chalé de %s aprendemos sobre %s." % [who, god, str(CABINS[active_cabin][1]).to_lower()], 8.0)
    if not cabin_talked.has(active_cabin):
        cabin_talked[active_cabin] = true
        _gain_xp(10)
        _toast("%s conta uma história. +10 XP" % who)
    else:
        _toast("%s sorri para você." % who)

func _rest() -> void:
    hearts = max_hearts
    energy = 100.0
    game_minutes += 60.0
    _toast("Você descansou: corações e energia restaurados.")
    _save_game()

func _show_quests() -> void:
    _panel("MISSÕES DO ACAMPAMENTO", "quests")
    var s: int = mini(int(quests["shadows"]), 3)
    var q1 := "[CONCLUÍDA]" if quest_done["shadows"] else "[ATIVA]"
    _label(q1 + " Sussurros na floresta", Vector2(100, 130), 22, Color("d6a64b"))
    _label("Derrote 3 sombras que rondam o acampamento (%d/3)." % s, Vector2(100, 170), 17)
    _label("Recompensa: 80 dracmas - 120 XP - amizade com Lia", Vector2(100, 204), 15, Color("9bd5d0"))
    var q2 := "[CONCLUÍDA]" if quest_done["cabin"] else "[BÔNUS]"
    _label(q2 + " Conheça um chalé novo", Vector2(100, 290), 22, Color("d97e9d"))
    _label("Entre em um chalé pela porta e investigue o baú.", Vector2(100, 330), 17)
    _label("Recompensa: 40 dracmas - 40 XP", Vector2(100, 364), 15, Color("9bd5d0"))
    var q3 := "[CONCLUÍDA]" if quest_done["friends"] else "[BÔNUS]"
    _label(q3 + " Faça amigos", Vector2(100, 440), 22, Color("6cc2a0"))
    _label("Converse com Lia, Nico e Quíron (%d/3)." % met.size(), Vector2(100, 480), 17)
    _label("Recompensa: 60 XP", Vector2(100, 514), 15, Color("9bd5d0"))
    _back_button()

func _show_skills() -> void:
    _panel("ÁRVORE DE HABILIDADES", "skills")
    _label("NÍVEL %d   XP %d/100   Pontos: %d" % [level, xp, skill_points], Vector2(75, 100), 18, Color("9bd5d0"))
    var defs := [["speed", "Passo veloz", 1, "+20% de velocidade", Vector2(120, 190), Color("659c83"), ""],
        ["guard", "Defesa divina", 1, "mais tempo invulnerável após dano", Vector2(120, 280), Color("6d8fb3"), "speed"],
        ["ancestral", "Poder ancestral", 2, "+1 de dano no poder do chalé", Vector2(120, 370), CABINS[divine_parent][2], "guard"]]
    for d in defs:
        var key: String = str(d[0])
        var cost: int = int(d[2])
        var req: String = str(d[6])
        var learned: bool = skills[key]
        var locked: bool = req != "" and not skills[req]
        var label := str(d[1]) + "  -  " + str(cost) + (" ponto" if cost == 1 else " pontos")
        if learned:
            label += "  (aprendida)"
        var b := _button(label, d[4], Vector2(420, 58), func(): _learn_skill(key, cost), d[5])
        b.disabled = learned or locked
        _label(str(d[3]) + (" - requer " + {"speed": "Passo veloz", "guard": "Defesa divina"}.get(req, "") if locked else ""), Vector2(570, d[4].y + 16), 15, Color("b7c9bf"))
    _label("Ganhe 1 ponto a cada nível. XP vem de combates e missões.", Vector2(120, 470), 16, Color("b7c9bf"))
    _back_button()

func _learn_skill(key: String, cost: int) -> void:
    if skill_points >= cost:
        skill_points -= cost
        skills[key] = true
        _toast("Habilidade aprendida!")
    else:
        _toast("Pontos insuficientes. Suba de nível para ganhar mais.")
    _show_skills()

func _show_relationships() -> void:
    _panel("AMIZADES E RELACIONAMENTOS", "friends")
    _label("Converse com cada pessoa uma vez por dia para fortalecer a amizade.", Vector2(110, 110), 16, Color("b7c9bf"))
    var names := ["Lia", "Nico", "Quíron"]
    var notes := ["amiga e possível romance", "amizade", "mentor"]
    for i in range(3):
        _label("%s   (%s)" % [names[i], notes[i]], Vector2(200, 170 + i * 90), 20, [Color("d97e9d"), Color("9bd5d0"), Color("d6a64b")][i])
    _label("Romances são opcionais e progressivos.", Vector2(110, 470), 15, Color("d8b8c1"))
    _back_button()

func _show_shop() -> void:
    _panel("LOJA DO ACAMPAMENTO", "shop")
    _label("Dracmas: " + str(coins), Vector2(75, 100), 18, Color("d6a64b"))
    var b1 := _button("Camisa de treino  -  40" + ("  (comprada)" if owned["shirt"] else ""), Vector2(110, 180), Vector2(340, 58), func(): _buy("shirt", 40), Color("659c83"))
    b1.disabled = owned["shirt"]
    _label("+1 coração máximo", Vector2(120, 246), 15, Color("b7c9bf"))
    var b2 := _button("Manto do chalé  -  80" + ("  (comprado)" if owned["cloak"] else ""), Vector2(480, 180), Vector2(340, 58), func(): _buy("cloak", 80), Color("8e77bd"))
    b2.disabled = owned["cloak"]
    _label("+1 de dano no poder", Vector2(490, 246), 15, Color("b7c9bf"))
    _button("Poção de energia  -  25  (tem %d)" % potions, Vector2(850, 180), Vector2(340, 58), func(): _buy("potion", 25), Color("c84d48"))
    _label("Restaura 2 corações (tecla 1)", Vector2(860, 246), 15, Color("b7c9bf"))
    _back_button()

func _buy(item: String, price: int) -> void:
    if coins < price:
        _toast("Você precisa de mais dracmas.")
        return
    coins -= price
    match item:
        "shirt":
            owned["shirt"] = true
            max_hearts = 6
            hearts = mini(hearts + 1, max_hearts)
        "cloak":
            owned["cloak"] = true
        "potion":
            potions += 1
    _toast("Item comprado!")
    _show_shop()

func _show_inventory() -> void:
    _panel("MOCHILA", "inventory")
    _label("Itens equipados e achados durante a aventura", Vector2(75, 100), 16, Color("9bd5d0"))
    _label("Espada de bronze - equipada (dano 1)", Vector2(110, 180), 19, Color("fff4d0"))
    _label("Camisa de treino - " + ("equipada (+1 coração)" if owned["shirt"] else "não comprada"), Vector2(110, 230), 19, Color("fff4d0") if owned["shirt"] else Color("7f8c94"))
    _label("Manto do chalé - " + ("equipado (+1 dano no poder)" if owned["cloak"] else "não comprado"), Vector2(110, 280), 19, Color("fff4d0") if owned["cloak"] else Color("7f8c94"))
    _label("Poções de energia: %d" % potions, Vector2(110, 340), 19, Color("6cc2a0"))
    _button("Usar poção", Vector2(110, 385), Vector2(220, 50), func(): _use_potion(); _show_inventory(), Color("6cc2a0"))
    _label("Corações: %d/%d" % [hearts, max_hearts], Vector2(110, 460), 18, Color("ff8d83"))
    _back_button()

# ---------------------------------------------------------------- jogo
func _gain_xp(n: int) -> void:
    xp += n
    while xp >= 100:
        xp -= 100
        level += 1
        skill_points += 1
        _toast("Nível %d! +1 ponto de habilidade" % level, 3.0)

func _use_potion() -> void:
    if potions <= 0:
        _toast("Você não tem poções.")
    elif hearts >= max_hearts:
        _toast("Seus corações já estão cheios.")
    else:
        potions -= 1
        hearts = mini(hearts + 2, max_hearts)
        _toast("Poção usada: +2 corações")

func _interact() -> void:
    if screen != "camp":
        return
    if target.is_empty():
        _toast("Nada por perto para interagir.", 1.4)
        return
    if target["type"] == "npc":
        _talk_npc(str(target["id"]))
    elif target["type"] == "cabin":
        _enter_cabin(int(target["id"]))

func _talk_npc(who: String) -> void:
    var f: int = int(friendship[who])
    var lines: Array = NPC_LINES[who]
    var text: String = str(lines[mini(f, lines.size() - 1)])
    if not talked_today.has(who):
        talked_today[who] = true
        friendship[who] = mini(f + 1, 5)
        met[who] = true
        _gain_xp(10)
        _toast("Amizade com %s aumentou! (%d/5)" % [who, int(friendship[who])])
        if met.size() >= 3 and not quest_done["friends"]:
            quest_done["friends"] = true
            _gain_xp(60)
            _toast("Missão concluída: Faça amigos! +60 XP", 3.2)
    else:
        text += "  (Volte amanhã para conversar mais.)"
    _say(who + ": " + text, 8.0)

func _attack() -> void:
    if screen != "camp" or attack_cd > 0.0:
        return
    attack_cd = 0.4
    slash_t = 0.18
    var hit := false
    for m in monsters.duplicate():
        var d: Vector2 = m["pos"] - player_pos
        if d.length() < 92.0 and (d.normalized().dot(facing) > -0.3 or d.length() < 44.0):
            _hurt_monster(m, 1, d)
            hit = true
    if not hit:
        _toast("O golpe corta o ar.", 0.8)

func _power_slot(slot: int) -> void:
    if screen != "camp":
        return
    if slot == 1:
        if power_cd > 0.0:
            return
        if energy < 30.0:
            _toast("Energia insuficiente (30).", 1.2)
            return
        energy -= 30.0
        power_cd = 0.8
        var dmg := 2 + (1 if skills["ancestral"] else 0) + (1 if owned["cloak"] else 0)
        var gcol: Color = CABINS[divine_parent][2]
        fx.append({"pos": player_pos + Vector2(0, -20), "r": 150.0, "t": 0.0, "dur": 0.5, "col": gcol})
        var hit := 0
        for m in monsters.duplicate():
            var d: Vector2 = m["pos"] - player_pos
            if d.length() < 150.0:
                _hurt_monster(m, dmg, d)
                hit += 1
        _toast("Poder de %s! %d alvo(s)" % [str(CABINS[divine_parent][0]), hit], 1.4)
    else:
        if shield_cd > 0.0:
            return
        if energy < 40.0:
            _toast("Energia insuficiente (40).", 1.2)
            return
        energy -= 40.0
        shield_t = 4.0
        shield_cd = 6.0
        _toast("Escudo divino ativo por 4 segundos.", 1.4)

func _hurt_monster(m: Dictionary, dmg: int, dir: Vector2) -> void:
    m["hp"] = int(m["hp"]) - dmg
    m["flash"] = 0.18
    var pos: Vector2 = m["pos"]
    m["pos"] = pos + dir.normalized() * 30.0
    if int(m["hp"]) <= 0:
        monsters.erase(m)
        kills += 1
        var drop := randi_range(10, 20)
        coins += drop
        _gain_xp(20)
        fx.append({"pos": pos + Vector2(0, -30), "r": 40.0, "t": 0.0, "dur": 0.4, "col": Color("b48cff")})
        _toast("Sombra derrotada! +%d dracmas, +20 XP" % drop, 1.8)
        if not quest_done["shadows"]:
            quests["shadows"] = int(quests["shadows"]) + 1
            if int(quests["shadows"]) >= 3:
                quest_done["shadows"] = true
                coins += 80
                _gain_xp(120)
                friendship["Lia"] = mini(int(friendship["Lia"]) + 1, 5)
                _say("Missão concluída: Sussurros na floresta! +80 dracmas, +120 XP e Lia ficou mais amiga.", 9.0)
                _save_game()

func _player_hit() -> void:
    if hurt_cd > 0.0 or shield_t > 0.0:
        return
    hearts -= 1
    hurt_cd = 1.7 if skills["guard"] else 1.0
    fx.append({"pos": player_pos + Vector2(0, -26), "r": 34.0, "t": 0.0, "dur": 0.3, "col": Color("ff6b5e")})
    _toast("Ai! -1 coração", 1.0)
    if hearts <= 0:
        _faint()

func _faint() -> void:
    coins = int(coins * 0.9)
    hearts = max_hearts
    energy = 100.0
    player_pos = Vector2(640, 480)
    monsters.clear()
    spawn_timer = 6.0
    _say("Você desmaiou e acordou junto à fogueira. Perdeu 10% dos dracmas.", 8.0)

func _spawn_monster() -> void:
    var pts := [Vector2(180, 540), Vector2(1090, 540), Vector2(300, 330), Vector2(960, 330), Vector2(420, 590), Vector2(880, 590), Vector2(250, 260), Vector2(1000, 260)]
    pts.shuffle()
    for p in pts:
        if p.distance_to(player_pos) > 300.0:
            var hp: int = [2, 3, 4][difficulty]
            monsters.append({"pos": p, "hp": hp, "max": hp, "cd": 1.2, "flash": 0.0, "face": 1.0, "bob": randf() * 6.0})
            return

func _update_camp(delta: float) -> void:
    game_minutes += delta
    if game_minutes >= 1440.0:
        game_minutes -= 1440.0
        day += 1
        talked_today.clear()
        _toast("Amanheceu um novo dia (dia %d)." % day, 3.0)
    attack_cd = maxf(0.0, attack_cd - delta)
    power_cd = maxf(0.0, power_cd - delta)
    shield_cd = maxf(0.0, shield_cd - delta)
    shield_t = maxf(0.0, shield_t - delta)
    hurt_cd = maxf(0.0, hurt_cd - delta)
    slash_t = maxf(0.0, slash_t - delta)
    energy = minf(100.0, energy + 7.0 * delta)
    walk_t += delta
    var dir := Input.get_vector("move_left", "move_right", "move_up", "move_down")
    if joystick_vector.length() > 0.12:
        dir = joystick_vector
    moving = dir.length() > 0.1
    if moving:
        facing = dir.normalized()
        var spd := 150.0 * (1.2 if skills["speed"] else 1.0)
        var step := dir.limit_length(1.0) * spd * delta
        var nx := player_pos + Vector2(step.x, 0)
        if not _blocked(nx):
            player_pos = nx
        var ny := player_pos + Vector2(0, step.y)
        if not _blocked(ny):
            player_pos = ny
    # monstros
    var alive := monsters.size()
    if alive < 2:
        spawn_timer -= delta
        if spawn_timer <= 0.0:
            _spawn_monster()
            spawn_timer = 10.0
    for m in monsters:
        var d: Vector2 = player_pos - m["pos"]
        var dist := d.length()
        m["bob"] = float(m["bob"]) + delta * 3.0
        m["flash"] = maxf(0.0, float(m["flash"]) - delta)
        m["cd"] = maxf(0.0, float(m["cd"]) - delta)
        if absf(d.x) > 4.0:
            m["face"] = signf(d.x)
        if dist < 380.0 and dist > 28.0:
            var spd_m := 44.0 + 12.0 * difficulty
            var mp: Vector2 = m["pos"] + d.normalized() * spd_m * delta
            mp.x = clampf(mp.x, 20.0, 1260.0)
            mp.y = clampf(mp.y, 100.0, 616.0)
            m["pos"] = mp
        if dist < 34.0 and float(m["cd"]) <= 0.0:
            _player_hit()
            m["cd"] = [1.8, 1.4, 1.0][difficulty]
    for f in fx.duplicate():
        f["t"] = float(f["t"]) + delta
        if float(f["t"]) >= float(f["dur"]):
            fx.erase(f)
    # alvo de interação
    target = {}
    var best := 9999.0
    for n in npcs:
        var np: Vector2 = n["pos"]
        var dd := np.distance_to(player_pos)
        if dd < 70.0 and dd < best:
            best = dd
            target = {"type": "npc", "id": n["name"], "label": "E  Conversar com " + str(n["name"])}
    for i in range(20):
        var dd := _cabin_door(i).distance_to(player_pos)
        if dd < 52.0 and dd < best:
            best = dd
            target = {"type": "cabin", "id": i, "label": "E  Entrar no chalé %02d (%s)" % [i + 1, str(CABINS[i][0])]}

func _process(delta: float) -> void:
    if toast_time > 0.0:
        toast_time -= delta
        if toast_time <= 0.0:
            toast = ""
    if dialogue_time > 0.0:
        dialogue_time -= delta
    if screen == "camp":
        _update_camp(delta)
    queue_redraw()

# ---------------------------------------------------------------- desenho
func _text(s: String, pos: Vector2, size_px: int, color: Color, width := -1.0, align := HORIZONTAL_ALIGNMENT_LEFT) -> void:
    var f := ThemeDB.fallback_font
    draw_string(f, pos + Vector2(1, 1), s, align, width, size_px, Color(0, 0, 0, 0.75))
    draw_string(f, pos, s, align, width, size_px, color)

func _panel_rect(r: Rect2, col := Color("1e3446"), alpha := 0.92) -> void:
    var c := col
    c.a = alpha
    draw_rect(r, c, true)
    draw_rect(r, Color("5d7180"), false, 2.0)

func _heart(c: Vector2, s: float, col: Color) -> void:
    draw_circle(c + Vector2(-s * 0.25, -s * 0.1), s * 0.29, col)
    draw_circle(c + Vector2(s * 0.25, -s * 0.1), s * 0.29, col)
    draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.52, 0), c + Vector2(s * 0.52, 0), c + Vector2(0, s * 0.58)]), col)

func _shadow(p: Vector2, w: float) -> void:
    draw_set_transform(p, 0.0, Vector2(1.0, 0.35))
    draw_circle(Vector2.ZERO, w * 0.5, Color(0, 0, 0, 0.28))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, VIEW), Color("152638"))
    match screen:
        "title", "help":
            _draw_backdrop(0.62)
            if screen == "title":
                _draw_title_sprites()
        "creation":
            _draw_backdrop(0.78)
            _draw_creation_preview()
        "camp":
            _draw_camp()
        "cabins":
            _draw_backdrop(0.8)
            draw_rect(Rect2(40, 24, 1200, 672), Color(0.12, 0.3, 0.28, 0.9), true)
            for i in range(20):
                var x := 70.0 + (i % 4) * 270.0
                var y := 130.0 + (i / 4) * 78.0
                var c: Color = CABINS[i][2]
                draw_rect(Rect2(x, y, 240, 54), c.darkened(0.55), true)
        "cabin":
            _draw_cabin()
        _:
            _draw_backdrop(0.85)
            draw_rect(Rect2(30, 24, 1220, 672), Color(0.12, 0.2, 0.28, 0.94), true)
            draw_rect(Rect2(30, 24, 1220, 672), Color("5d7180"), false, 2.0)
            _draw_panel_extras()
    _draw_toast()

func _draw_backdrop(dark: float) -> void:
    var bg := _t("bg_camp")
    if bg != null:
        draw_texture(bg, Vector2.ZERO)
    draw_rect(Rect2(Vector2.ZERO, VIEW), Color(0.06, 0.11, 0.17, dark), true)

func _draw_title_sprites() -> void:
    var order := [["pc_garoto_frente", 160.0], ["pc_garota_frente", 280.0], ["pc_centauro_frente", 400.0], ["pc_sombra_frente", 540.0]]
    var x := 80.0
    for o in order:
        var t := _t(str(o[0]))
        if t != null:
            var s := t.get_size() * 2.0
            draw_texture_rect(t, Rect2(Vector2(x, 620.0 - s.y), s), false)
            x += s.x + 34.0
    for i in range(4):
        var ct := _t("cabin_" + ["sol", "lua", "folha", "estrela"][i])
        if ct != null:
            draw_texture_rect(ct, Rect2(Vector2(760 + i * 120, 470), ct.get_size() * 1.5), false)

func _draw_creation_preview() -> void:
    _panel_rect(Rect2(840, 340, 300, 250))
    var col: Color = CABINS[divine_parent][2]
    draw_circle(Vector2(990, 520), 58, Color(col.r, col.g, col.b, 0.3))
    var t := _t("pc_" + ["garoto", "garota"][model] + "_frente")
    if t != null:
        var s := t.get_size() * 2.2
        draw_texture_rect(t, Rect2(Vector2(990 - s.x * 0.5, 545 - s.y), s), false)
    _text(player_name, Vector2(850, 580), 16, Color("fff4d0"), 280.0, HORIZONTAL_ALIGNMENT_CENTER)

func _draw_panel_extras() -> void:
    if panel_kind == "friends":
        var names := ["Lia", "Nico", "Quíron"]
        var tex_names := ["garota", "garoto", "centauro"]
        for i in range(3):
            var t := _t("pc_" + tex_names[i] + "_frente")
            if t != null:
                var sc := 0.8 if i < 2 else 0.5
                var s := t.get_size() * sc
                draw_texture_rect(t, Rect2(Vector2(120, 170 + i * 90 + 54 - s.y), s), false)
            var f: int = int(friendship[names[i]])
            for k in range(5):
                draw_circle(Vector2(215 + k * 34, 218 + i * 90), 11, Color("d97e9d") if k < f else Color("34485a"))

func _day_alpha() -> float:
    var h := game_minutes / 60.0
    if h >= 20.0 or h < 5.0:
        return 0.34
    if h >= 18.0:
        return (h - 18.0) / 2.0 * 0.34
    if h < 7.0:
        return (7.0 - h) / 2.0 * 0.34
    return 0.0

func _draw_camp() -> void:
    var bg := _t("bg_camp")
    if bg != null:
        draw_texture(bg, Vector2.ZERO)
    var list: Array = statics.duplicate()
    list.append({"y": player_pos.y, "t": null, "kind": "player"})
    for n in npcs:
        var np: Vector2 = n["pos"]
        list.append({"y": np.y, "t": null, "kind": "npc", "npc": n})
    for m in monsters:
        var mp: Vector2 = m["pos"]
        list.append({"y": mp.y, "t": null, "kind": "monster", "m": m})
    list.sort_custom(func(a, b): return float(a["y"]) < float(b["y"]))
    for it in list:
        if it.has("kind"):
            match it["kind"]:
                "player":
                    _draw_player()
                "npc":
                    _draw_npc(it["npc"])
                "monster":
                    _draw_monster(it["m"])
        else:
            var t: Texture2D = it["t"]
            draw_texture(t, it["p"], it["m"])
            if it.has("num"):
                var p: Vector2 = it["p"]
                var s: Vector2 = it["s"]
                var c: Color = it["col"]
                draw_rect(Rect2(p.x + s.x * 0.5 - 12, p.y - 1, 24, 14), Color(0.05, 0.1, 0.16, 0.85), true)
                draw_rect(Rect2(p.x + s.x * 0.5 - 12, p.y - 1, 24, 3), c, true)
                _text(str(it["num"]), Vector2(p.x + s.x * 0.5 - 12, p.y + 10), 11, Color("fff4d0"), 24.0, HORIZONTAL_ALIGNMENT_CENTER)
            elif it.has("label"):
                var p2: Vector2 = it["p"]
                var s2: Vector2 = it["s"]
                _text(str(it["label"]), Vector2(p2.x, p2.y + s2.y + 12), 12, Color("fff4d0"), s2.x, HORIZONTAL_ALIGNMENT_CENTER)
    # brilho da fogueira e efeitos
    var flick := 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.012)
    draw_circle(Vector2(640, 418), 60.0 + flick * 6.0, Color(1.0, 0.65, 0.25, 0.10 + 0.05 * flick))
    for f in fx:
        var k: float = float(f["t"]) / float(f["dur"])
        var c: Color = f["col"]
        c.a = 0.85 * (1.0 - k)
        draw_arc(f["pos"], float(f["r"]) * (0.25 + 0.75 * k), 0.0, TAU, 40, c, 5.0)
    if slash_t > 0.0:
        var ang := facing.angle()
        draw_arc(player_pos + Vector2(0, -26), 50.0, ang - 0.95, ang + 0.95, 14, Color(1, 1, 0.8, slash_t / 0.18), 6.0)
    var na := _day_alpha()
    if na > 0.0:
        draw_rect(Rect2(0, 64, VIEW.x, VIEW.y - 64), Color(0.04, 0.07, 0.22, na), true)
    _draw_hud()

func _player_tex_name() -> String:
    var who: String = ["garoto", "garota"][model]
    var pose := "frente"
    if absf(facing.x) > absf(facing.y):
        pose = "dir" if facing.x > 0.0 else "esq"
    elif facing.y < 0.0:
        pose = "dir"
    return "pc_" + who + "_" + pose

func _draw_player() -> void:
    var t := _t(_player_tex_name())
    if t == null:
        return
    var s := t.get_size()
    var bob := -absf(sin(walk_t * 11.0)) * 3.0 if moving else 0.0
    var tint := Color.WHITE
    if hurt_cd > 0.0 and int(hurt_cd * 14.0) % 2 == 0:
        tint = Color(1.0, 0.55, 0.55)
    _shadow(player_pos, 30.0)
    if shield_t > 0.0:
        draw_circle(player_pos + Vector2(0, -30), 40.0, Color(0.55, 0.75, 1.0, 0.22))
        draw_arc(player_pos + Vector2(0, -30), 40.0, 0.0, TAU, 28, Color(0.7, 0.9, 1.0, 0.8), 3.0)
    draw_texture(t, player_pos + Vector2(-s.x * 0.5, -s.y + bob), tint)
    _text(player_name, player_pos + Vector2(-60, -s.y - 6), 12, CABINS[divine_parent][2].lightened(0.35), 120.0, HORIZONTAL_ALIGNMENT_CENTER)

func _draw_npc(n: Dictionary) -> void:
    var t := _t("pc_" + str(n["tex"]) + "_frente")
    if t == null:
        return
    var np: Vector2 = n["pos"]
    var s := t.get_size()
    var bob := sin(Time.get_ticks_msec() * 0.004 + np.x) * 1.5
    _shadow(np, 30.0 if str(n["tex"]) != "centauro" else 54.0)
    var tint: Color = n["tint"]
    draw_texture(t, np + Vector2(-s.x * 0.5, -s.y + bob), tint)
    _text(str(n["name"]), np + Vector2(-60, -s.y - 6), 12, Color("fff4d0"), 120.0, HORIZONTAL_ALIGNMENT_CENTER)

func _draw_monster(m: Dictionary) -> void:
    var face: float = float(m["face"])
    var t := _t("pc_sombra_" + ("dir" if face > 0.0 else "esq"))
    if t == null:
        return
    var mp: Vector2 = m["pos"]
    var s := t.get_size()
    var bob := sin(float(m["bob"])) * 4.0
    var tint := Color(1, 1, 1, 0.92)
    if float(m["flash"]) > 0.0:
        tint = Color(2.2, 1.6, 1.6, 1.0)
    _shadow(mp, 34.0)
    draw_texture(t, mp + Vector2(-s.x * 0.5, -s.y - 8 + bob), tint)
    var bw := 34.0
    var frac := float(int(m["hp"])) / float(int(m["max"]))
    draw_rect(Rect2(mp.x - bw * 0.5, mp.y - s.y - 16, bw, 5), Color(0, 0, 0, 0.7), true)
    draw_rect(Rect2(mp.x - bw * 0.5, mp.y - s.y - 16, bw * frac, 5), Color("c8504a"), true)

func _draw_hud() -> void:
    _panel_rect(Rect2(8, 4, 340, 56), Color("14263a"), 0.94)
    for i in range(max_hearts):
        _heart(Vector2(26 + i * 24, 20), 18.0, Color("e04a52") if i < hearts else Color("3b2c37"))
    draw_circle(Vector2(222, 18), 8, Color("e0b040"))
    draw_circle(Vector2(222, 18), 4, Color("a87d20"))
    _text(str(coins), Vector2(236, 24), 16, Color("ffe7a0"))
    _text("Nv %d" % level, Vector2(290, 24), 15, Color("9bd5d0"))
    draw_rect(Rect2(20, 38, 150, 8), Color("0c1822"), true)
    draw_rect(Rect2(20, 38, 150.0 * energy / 100.0, 8), Color("4aa3e0"), true)
    draw_rect(Rect2(182, 38, 150, 8), Color("0c1822"), true)
    draw_rect(Rect2(182, 38, 150.0 * float(xp) / 100.0, 8), Color("e0b040"), true)
    _text("ENERGIA", Vector2(20, 56), 9, Color("9bd5d0"))
    _text("XP %d/100" % xp, Vector2(182, 56), 9, Color("ffe7a0"))
    if skill_points > 0:
        draw_circle(Vector2(662, 14), 9, Color("e04a52"))
        _text("!", Vector2(659, 19), 13, Color.WHITE)
    var hh := int(game_minutes / 60.0)
    var mm := int(game_minutes) % 60
    _panel_rect(Rect2(1080, 4, 192, 56), Color("14263a"), 0.94)
    _text("Dia %d  -  %02d:%02d" % [day, hh, mm], Vector2(1092, 26), 15, Color("b7c9bf"))
    _text("Poder: " + str(CABINS[divine_parent][0]), Vector2(1092, 48), 15, CABINS[divine_parent][2])
    # barra rápida
    var ox := 476.0
    var oy := 646.0
    var slots := [["Poção", str(potions), 0.0, "1"], ["Poder", "", power_cd / 0.8 if energy >= 30.0 else 1.0, "K"], ["Escudo", "", shield_cd / 6.0 if energy >= 40.0 or shield_cd > 0.0 else 1.0, "L"], ["Ataque", "", attack_cd / 0.4, "Esp"]]
    _panel_rect(Rect2(ox - 12, oy - 10, 4 * 82 + 8, 66), Color("14263a"), 0.85)
    for i in range(4):
        var slot := Rect2(ox + i * 82, oy, 70, 46)
        draw_rect(slot, Color("314a59"), true)
        draw_rect(slot, Color("9bd5d0") if i == 0 else Color("5d7180"), false, 2.0)
        _slot_icon(i, Rect2(slot.position + Vector2(18, 4), Vector2(34, 30)))
        var cd: float = clampf(float(slots[i][2]), 0.0, 1.0)
        if cd > 0.0:
            draw_rect(Rect2(slot.position.x, slot.position.y + slot.size.y * (1.0 - cd), slot.size.x, slot.size.y * cd), Color(0, 0, 0, 0.5), true)
        _text(str(slots[i][3]), slot.position + Vector2(5, 14), 11, Color("ffe7a0"))
        _text(str(slots[i][1]) if str(slots[i][1]) != "" else str(slots[i][0]), slot.position + Vector2(0, 42), 11, Color("fff4d0"), 70.0, HORIZONTAL_ALIGNMENT_CENTER)
    # joystick
    if _touch_visible():
        var base := Vector2(150, 596)
        draw_circle(base, 74, Color(0.08, 0.15, 0.22, 0.6))
        draw_arc(base, 74, 0.0, TAU, 32, Color("9bd5d0"), 3.0)
        draw_circle(base + joystick_vector * 42.0, 30, Color(0.25, 0.55, 0.58, 0.9))
        draw_arc(base + joystick_vector * 42.0, 30, 0.0, TAU, 20, Color("d6a64b"), 3.0)
    else:
        _text("WASD mover - E interagir - Espaço atacar - K poder - L escudo - 1 poção - Esc pausa", Vector2(8, 712), 11, Color(1, 1, 1, 0.8))
    # prompt de interação
    if not target.is_empty():
        var lab := str(target["label"])
        _panel_rect(Rect2(VIEW.x * 0.5 - 170, 590, 340, 32), Color("14263a"), 0.9)
        _text(lab, Vector2(VIEW.x * 0.5 - 160, 612), 15, Color("ffe7a0"), 320.0, HORIZONTAL_ALIGNMENT_CENTER)
    # diálogo
    if dialogue_time > 0.0:
        _panel_rect(Rect2(260, 524, 760, 60), Color("14263a"), 0.92)
        _text(dialogue, Vector2(276, 548), 15, Color("fff4d0"), 730.0)

func _slot_icon(i: int, r: Rect2) -> void:
    var c := r.get_center()
    match i:
        0:
            draw_rect(Rect2(c.x - 7, c.y - 4, 14, 14), Color("e04a52"), true)
            draw_rect(Rect2(c.x - 3, c.y - 11, 6, 8), Color("c9d6dd"), true)
        1:
            var gc: Color = CABINS[divine_parent][2]
            draw_circle(c, 12, gc.darkened(0.3))
            draw_circle(c, 7, gc.lightened(0.3))
        2:
            draw_colored_polygon(PackedVector2Array([c + Vector2(-11, -10), c + Vector2(11, -10), c + Vector2(10, 4), c + Vector2(0, 13), c + Vector2(-10, 4)]), Color("8fc4ee"))
        _:
            draw_line(c + Vector2(-10, 10), c + Vector2(10, -10), Color("d8dde2"), 4.0)
            draw_line(c + Vector2(-12, 4), c + Vector2(-4, 12), Color("b67f62"), 4.0)

func _draw_toast() -> void:
    if toast == "":
        return
    var y := 74.0 if screen == "camp" else 660.0
    if screen == "camp" and dialogue_time > 0.0:
        y = 74.0
    _panel_rect(Rect2(VIEW.x * 0.5 - 250, y, 500, 34), Color("253c4b"), 0.95)
    _text(toast, Vector2(VIEW.x * 0.5 - 240, y + 23), 15, Color("ffe7a0"), 480.0, HORIZONTAL_ALIGNMENT_CENTER)

func _draw_cabin() -> void:
    var col: Color = CABINS[active_cabin][2]
    draw_rect(Rect2(45, 24, 1190, 672), Color("3b2f3f"), true)
    draw_rect(Rect2(110, 130, 1060, 420), col.darkened(0.62), true)
    for i in range(14):
        draw_line(Vector2(110, 130 + i * 30), Vector2(1170, 130 + i * 30), Color(0, 0, 0, 0.16), 2.0)
    draw_rect(Rect2(110, 130, 1060, 90), col.darkened(0.45), true)
    draw_rect(Rect2(110, 130, 1060, 420), Color("6b5a66"), false, 4.0)
    # cama
    draw_rect(Rect2(840, 280, 250, 120), Color("7a5c49"), true)
    draw_rect(Rect2(850, 290, 230, 100), col.darkened(0.15), true)
    draw_rect(Rect2(850, 290, 60, 100), Color("e7dcc8"), true)
    _text("Cantinho de descanso", Vector2(840, 270), 15, Color("9bd5d0"))
    # baú
    var crate := _t("crate_b" if opened_chests.has(active_cabin) else "crate_a")
    if crate != null:
        var s := crate.get_size() * 2.6
        draw_texture_rect(crate, Rect2(Vector2(270 - s.x * 0.5, 440 - s.y), s), false)
    _text("Baú do chalé", Vector2(200, 270), 15, Color("ffe7a0"))
    # morador
    var res: String = ["pc_garota_frente", "pc_garoto_frente", "pc_centauro_frente"][active_cabin % 3]
    var rt := _t(res)
    if rt != null:
        var rs := rt.get_size() * 2.2
        _shadow(Vector2(560, 470), 90.0)
        draw_texture_rect(rt, Rect2(Vector2(560 - rs.x * 0.5, 470 - rs.y), rs), false, col.lightened(0.55))
    _text(str(RESIDENTS[active_cabin]), Vector2(460, 490), 16, Color("d97e9d"), 200.0, HORIZONTAL_ALIGNMENT_CENTER)
    if dialogue_time > 0.0:
        _panel_rect(Rect2(160, 540, 960, 40), Color("14263a"), 0.92)
        _text(dialogue, Vector2(176, 566), 15, Color("fff4d0"), 930.0)

# ---------------------------------------------------------------- save
func _has_save() -> bool:
    return FileAccess.file_exists(SAVE_PATH)

func _save_game() -> void:
    var data := {"v": 2, "name": player_name, "model": model, "parent": divine_parent, "difficulty": difficulty, "level": level, "xp": xp,
        "sp": skill_points, "coins": coins, "hearts": hearts, "max_hearts": max_hearts, "energy": energy, "kills": kills, "potions": potions,
        "owned": owned, "skills": skills, "quests": quests, "qdone": quest_done, "friends": friendship, "met": met.keys(),
        "chests": opened_chests.keys(), "visited": visited_cabins.keys(), "cabin_talked": cabin_talked.keys(),
        "minutes": game_minutes, "day": day, "pos": [player_pos.x, player_pos.y], "sound": sound_on, "touch": touch_mode}
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f != null:
        f.store_string(JSON.stringify(data))
        f.close()

func _load_game() -> bool:
    if not _has_save():
        return false
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if f == null:
        return false
    var parsed: Variant = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        return false
    var d: Dictionary = parsed
    player_name = str(d.get("name", "Ari"))
    model = int(d.get("model", 0))
    divine_parent = clampi(int(d.get("parent", 0)), 0, 19)
    difficulty = clampi(int(d.get("difficulty", 1)), 0, 2)
    level = int(d.get("level", 1))
    xp = int(d.get("xp", 0))
    skill_points = int(d.get("sp", 0))
    coins = int(d.get("coins", 120))
    max_hearts = int(d.get("max_hearts", 5))
    hearts = clampi(int(d.get("hearts", max_hearts)), 1, max_hearts)
    energy = float(d.get("energy", 100.0))
    kills = int(d.get("kills", 0))
    potions = int(d.get("potions", 1))
    for k in ["shirt", "cloak"]:
        owned[k] = bool((d.get("owned", {}) as Dictionary).get(k, false))
    for k in ["speed", "guard", "ancestral"]:
        skills[k] = bool((d.get("skills", {}) as Dictionary).get(k, false))
    quests["shadows"] = int((d.get("quests", {}) as Dictionary).get("shadows", 0))
    for k in ["shadows", "cabin", "friends"]:
        quest_done[k] = bool((d.get("qdone", {}) as Dictionary).get(k, false))
    for k in ["Lia", "Nico", "Quíron"]:
        friendship[k] = clampi(int((d.get("friends", {}) as Dictionary).get(k, 0)), 0, 5)
    met = {}
    for v in d.get("met", []):
        met[str(v)] = true
    opened_chests = {}
    for v in d.get("chests", []):
        opened_chests[int(v)] = true
    visited_cabins = {}
    for v in d.get("visited", []):
        visited_cabins[int(v)] = true
    cabin_talked = {}
    for v in d.get("cabin_talked", []):
        cabin_talked[int(v)] = true
    game_minutes = float(d.get("minutes", 980.0))
    day = int(d.get("day", 1))
    var pa: Array = d.get("pos", [640, 470])
    player_pos = Vector2(float(pa[0]), float(pa[1]))
    if _blocked(player_pos):
        player_pos = Vector2(640, 480)
    sound_on = bool(d.get("sound", true))
    AudioServer.set_bus_mute(0, not sound_on)
    touch_mode = clampi(int(d.get("touch", 0)), 0, 2)
    monsters.clear()
    spawn_timer = 3.0
    talked_today = {}
    _say("Bem-vindo de volta, " + player_name + "!", 6.0)
    return true
